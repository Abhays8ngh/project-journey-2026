const btnE1 = document.querySelector(".btn");
const inpute1 = document.getElementById("input");
const resulte1 = document.getElementById("result");
const errore1 = document.getElementById("error");
const btn = document.getElementById("btn")


let errortime;
let oupttime;



function updatevalue() {
    if (inpute1.value <= 0 || isNaN(inpute1.value)) {
        errore1.innerText = "please enter a valid number";
        clearTimeout(errortime);
        errortime = setTimeout(() => {
            errore1.innerText = "";
            inpute1.value = "";
            
        }, 2000);
    }
    else {
        resulte1.innerText = (+inpute1.value / 2.2).toFixed(2);
        setTimeout(() => {
            errore1.innerText = "";
        }, 10);
        
        clearTimeout(oupttime);
        oupttime=setTimeout(() => {
            resulte1.innerText = "";
            inpute1.value = "";
            
        }, 12000);
    }
}









btn.addEventListener("click", () => {
    errore1.innerText = "";
    resulte1.innerText = "";
    inpute1.value = "";

})







inpute1.addEventListener(
    "input", updatevalue)



























btnE1.addEventListener("mouseover", (event) => {
    const x = event.pageX - btnE1.offsetLeft;
    const y = event.pageY - btnE1.offsetTop;
    btnE1.style.setProperty("--xpos", x + "px");
    btnE1.style.setProperty("--ypos", y + "px");

});
