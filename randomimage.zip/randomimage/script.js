const imageboxE1=document.querySelector(".imagebox");
const btnE1=document.querySelector(".btn");
btnE1.addEventListener("click",()=>
{
    imagnum=10;
    newimage();
});
function newimage(){
    for (let index = 0; index < imagnum; index++) {
        const newimageE1=document.createElement("img");
    newimageE1.src=`https://picsum.photos/300?random=${Math.floor(Math.random()*4000)}`;
    imageboxE1.appendChild(newimageE1);


}

        
    }
    